package com.sena.servicesecurity.DTO;

public interface IUserRoleDto extends IGenericDto{

	String getUser();
	String getRole();
}
