package com.sena.servicesecurity.Enums;

public enum NomeclaturaEnum {
	
	CALLE,
    NUMERO,
    GUION,
    OTRO
}
