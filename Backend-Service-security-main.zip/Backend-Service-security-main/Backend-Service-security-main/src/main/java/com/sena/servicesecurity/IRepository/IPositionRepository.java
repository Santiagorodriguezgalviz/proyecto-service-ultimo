package com.sena.servicesecurity.IRepository;

import org.springframework.stereotype.Repository;

import com.sena.servicesecurity.Entity.Position;

@Repository
public interface IPositionRepository extends IBaseRepository<Position, Long>{

}
