package com.sena.servicesecurity.DTO;

public interface IPositionDto extends IGenericDto{

	String getName();
	String getCode();
}
