package com.sena.servicesecurity.DTO;

public interface ICountryDto extends IGenericDto {
String getName_country();
String getCode_country();
}
