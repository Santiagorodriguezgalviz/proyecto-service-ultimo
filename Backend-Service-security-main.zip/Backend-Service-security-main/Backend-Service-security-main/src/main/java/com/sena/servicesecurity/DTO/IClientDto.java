package com.sena.servicesecurity.DTO;

public interface IClientDto extends IGenericDto{
	
	String getName();
	String getCode();
	String getType_document();
	String getDocument();
	Long getPerson_id();
	
}
