package com.sena.servicesecurity.IService;

import com.sena.servicesecurity.Entity.Position;

public interface IPositionService extends IBaseService<Position>{

}
